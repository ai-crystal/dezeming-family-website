import pandas as pd
#pd.show_versions()
data_file = '三个同心圆.csv'
csv_data = pd.read_csv(data_file)  # 读取训练数据
#print(csv_data.shape)
#因为读取的数据是横着排列的，因此我们需要得到里面每一个点的(X,Y)坐标时，应该先进行转置
csv_data_display = csv_data.T # 转置 .T
#print(csv_data_display.shape)
#print(csv_data_display.values)
x1 = csv_data_display.values[0]
y1 = csv_data_display.values[1]

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse

import numpy as np
from numpy import *
import numpy as np
from numpy import *
# 计算欧几里得距离
def Eclud_dist(vecA, vecB):
    return sqrt(sum(power(vecA - vecB, 2)))

points=np.array(csv_data).reshape(-1,2)
#print(points.shape)
#print(points)
m, n = np.shape(points)
#print(m)
#print(n)

def f_Roulette(_list):
    tr = random.random()
    for i in range(len(_list)):
        if i == 0 and _list[i] > tr:
            return 0
        else:
            if _list[i] > tr and _list[i - 1] <= tr:
                return i

def nearest(point, cluster_centers):
    min_dist = 90000000
    #当前已经初始化聚类中心的个数
    m = np.shape(cluster_centers)[0]
    #print('m = ', m)
    for i in range(m):
        #计算point与每个聚类中心之间的距离
        d = Eclud_dist(point, cluster_centers[i, ])
        #选择最短距离
        if min_dist > d:
            min_dist = d
    return min_dist

#得到初始的聚类中心
def get_cluster_origin_cent(points, k):
    #因为我们的数据是二维的，所以n是2
    m, n = np.shape(points)
    cluster_centers = np.mat(np.zeros((k, n)))
    #随机选择第一个聚类中心
    index = np.random.randint(0, m)
    #把聚类中心复制到数组里保存
    cluster_centers[0,] = np.copy(points[index,])

    #初始化一个距离序列
    d = [0.0 for _ in range(m)]
    #从第二个聚类中心开始找，一共找k个（最高的索引为k-1）
    for i in range(1, k):
        sum_denominator = 0
        sum_numerator = []
        for j in range(m):
            #对每一个样本找到最近的聚类中心点
            d[j] = nearest(points[j,], cluster_centers[0:i, ])
            #将所有的最短距离相加
            sum_denominator += d[j]
            sum_numerator.append(sum_denominator)
        sum_numerator = sum_numerator / sum_denominator
        #使用轮盘来得到随机中心点
        index = f_Roulette(sum_numerator)
        cluster_centers[i,] = np.copy(points[index,])

    return cluster_centers

##聚类中心
cluster_centers = get_cluster_origin_cent(points, 3)



# 高斯分布的概率密度函数
def prob(x, mu, sigma):
    n = shape(x)[0]
    # .I：求逆矩阵
    expOn = float(-0.5*(x-mu)*(sigma.I)*((x-mu).T))
    divBy = pow(2*pi, n/2)*pow(linalg.det(sigma), 0.5)
    return pow(e, expOn)/divBy

def EM(points, cluster_centers, maxIter=50):
    m, n = shape(points)
    # 初始化各高斯混合成分参数
    omega = [1/3, 1/3, 1/3]
    mu = [cluster_centers[0], cluster_centers[1], cluster_centers[2]]
    sigma = [mat([[0.1, 0], [0, 0.1]]) for x in range(3)]
    T_i2j = mat(zeros((m, 3)))
    #开始进行迭代
    for i in range(maxIter):
        #先遍历样本。求出所有需要求的参数
        for j in range(m):
            sumOmegaMulP = 0
            for k in range(3):
                T_i2j[j, k] = omega[k]*prob(points[j], mu[k], sigma[k])
                sumOmegaMulP += T_i2j[j, k]
            for k in range(3):
                T_i2j[j, k] /= sumOmegaMulP
        sumT_i2j = sum(T_i2j, axis=0)
        #使用参数更新高斯混合分布值
        for k in range(3):
            mu[k] = mat(zeros((1, n)))
            sigma[k] = mat(zeros((n, n)))
            for j in range(m):
                mu[k] += T_i2j[j, k]*points[j]
            mu[k] /= sumT_i2j[0, k]
            for j in range(m):
                sigma[k] += T_i2j[j, k]*(points[j]-mu[k]).T*(points[j]-mu[k])
            sigma[k] /= sumT_i2j[0, k]
            omega[k] = sumT_i2j[0, k]/m
    return T_i2j, sigma

#迭代20轮
for i in range(20):
    #定义画布绘制对象
    fig, ax = plt.subplots()
    #返回样本属于某一类的概率，以及这三组样本的协方差矩阵
    T_i2j, sigma = EM(points, cluster_centers, 1)
    #初始化分类数组
    clusterAssign = mat(zeros((m, 2)))
    m, n = shape(points)
    for i in range(m):
        # amx返回矩阵最大值，argmax返回矩阵最大值所在下标
        clusterAssign[i] = argmax(T_i2j[i, :]), amax(T_i2j[i, :])
    #把数据点分别归类到三类中，然后计算每一类的均值
    for j in range(3):
        pointsInCluster = points[nonzero(clusterAssign[:, 0] == j)[0]]
        #axis = 0：计算所有列中每一列的均值
        cluster_centers[j] = mean(pointsInCluster, axis = 0)
    m,n = points.shape
    mark = ['or', 'ob', 'og', 'ok']
    #把所有点根据其类别画到画布上
    for i in range(m):
        markIndex = int(clusterAssign[i, 0])
        plt.plot(points[i, 0], points[i, 1], mark[markIndex],markersize=4,zorder=1)
    #把聚类中心画到画布上，画的大一点(s=160)，边界设为黑色(edgecolors='k')
    cluster_centers_display = cluster_centers.T.A
    x1 = cluster_centers_display[0]
    x2 = cluster_centers_display[1]
    color = ['red','blue','green']
    #zorder=2表示画在plot的上层
    plt.scatter(x1,x2,s = 160, c=color,zorder=2, linewidths=4, edgecolors='k') #画点
    #对这三个类别，计算协方差矩阵的特征值和特征向量，根据特征值和特征向量来绘制分布椭圆
    for i in range(3):
        # 计算特征值lambda_和特征向量v
        lambda_, v = np.linalg.eig(sigma[i])
        # 存在负的特征值， 无法开方，取绝对值
        sqrt_lambda = np.sqrt(np.abs(lambda_))
        # 计算椭圆的长轴和短轴，乘以6使其范围大一些，再计算角度
        width = 6 * np.sqrt(1.0) * sqrt_lambda[0]
        height = 6 * np.sqrt(1.0) * sqrt_lambda[1]
        angle = np.rad2deg(np.arccos(v[0, 0]))
        ell1 = Ellipse(xy = cluster_centers[i].T, width=width, height=height, angle=angle, facecolor=color[i], alpha=0.3)
        ax.add_patch(ell1)
    #显示绘制结果
    plt.show()




























