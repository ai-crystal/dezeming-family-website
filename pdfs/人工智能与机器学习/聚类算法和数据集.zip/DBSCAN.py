import pandas as pd
#pd.show_versions()
data_file = '两条弧线(粗).csv'
csv_data = pd.read_csv(data_file)  # 读取训练数据
print(csv_data.shape)
#因为读取的数据是横着排列的，因此我们需要得到里面每一个点的(X,Y)坐标时，应该先进行转置
csv_data_display = csv_data.T # 转置 .T
print(csv_data_display.shape)
print(csv_data_display.values)
x1 = csv_data_display.values[0]
y1 = csv_data_display.values[1]

import matplotlib.pyplot as plt
plt.figure()
#plt.plot(x1,y1) #画线
plt.scatter(x1,y1,s = 5, c='green') #画点
plt.show()

import numpy as np
from numpy import *
# 计算欧几里得距离
def Eclud_dist(vecA, vecB):
    return sqrt(sum(power(vecA - vecB, 2)))

points=np.array(csv_data).reshape(-1,2)
points_tmp = []
print(points.shape[0])
for i in range(points.shape[0]):
    if(i % 3 == 1):
        points_tmp.append(points[i])
points=np.array(points_tmp)

points_tmp = []
print(points.shape[0])
for i in range(points.shape[0]):
    if(i % 3 == 1):
        points_tmp.append(points[i])
points=np.array(points_tmp)

points_tmp = []
print(points.shape[0])
for i in range(points.shape[0]):
    if(i % 3 == 1):
        points_tmp.append(points[i])
points=np.array(points_tmp)


print(points.shape[0])



#curIndex是当前点的坐标
def findNeighbor(curIndex,points,epsilon):
    Neighbor=[]
    for i in range(points.shape[0]):   #找到所有领域内对象
        temp=Eclud_dist(points[curIndex], points[i])   #欧氏距离
        if(temp <= epsilon):
            Neighbor.append(i)
    return Neighbor

def DBSCAN(points,epsilon,min_Points):
    visited_points = [] #已经访问的为空
    unvisited_points=[x for x in range(len(points))] #未访问的点的序号
    cluster = [-1 for y in range(len(points))]
    cluster_count = -1 #当前聚类类别编号
    #print(unvisited_points)
    #还有没有被访问的点就继续循环
    while len(unvisited_points) > 0:
        curIndex=random.choice(unvisited_points)
        unvisited_points.remove(curIndex)  #未访问列表中移除
        visited_points.append(curIndex)   #添加入访问列表
        NeighborPts = findNeighbor(curIndex, points, epsilon)
        if len(NeighborPts) < min_Points:
            cluster[curIndex] = -1 #标记为噪声点
        else:
            cluster_count = cluster_count + 1
            cluster[curIndex] = cluster_count
            #遍历邻近样本
            for i in NeighborPts:
                #该点没有被访问过，就开始判断
                if i not in visited_points:
                    unvisited_points.remove(i)
                    visited_points.append(i)
                    Ner_NeighborPts = findNeighbor(i, points, epsilon)
                    if len(Ner_NeighborPts) >= min_Points:
                        for a in Ner_NeighborPts:
                            #这样会不断扩增NeighborPts，直到没有临近点才结束遍历
                            if a not in NeighborPts:
                                NeighborPts.append(a)
                    if (cluster[i] == -1):
                        cluster[i] = cluster_count
    return cluster

epsilon=0.2
min_Points=20
Cluster=DBSCAN(points,epsilon,min_Points)

plt.scatter(points[:,0],points[:,1],c=Cluster)
plt.show()



