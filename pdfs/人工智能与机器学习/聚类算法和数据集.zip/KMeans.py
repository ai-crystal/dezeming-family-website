import pandas as pd
#pd.show_versions()
data_file = '两条弧线(粗).csv'
csv_data = pd.read_csv(data_file)  # 读取训练数据
print(csv_data.shape)
#因为读取的数据是横着排列的，因此我们需要得到里面每一个点的(X,Y)坐标时，应该先进行转置
csv_data_display = csv_data.T # 转置 .T
print(csv_data_display.shape)
print(csv_data_display.values)
x1 = csv_data_display.values[0]
y1 = csv_data_display.values[1]

import matplotlib.pyplot as plt
plt.figure()
#plt.plot(x1,y1) #画线
plt.scatter(x1,y1,s = 5, c='green') #画点
#plt.show()


import numpy as np
from numpy import *
# 计算欧几里得距离
def Eclud_dist(vecA, vecB):
    return sqrt(sum(power(vecA - vecB, 2)))

points=np.array(csv_data).reshape(-1,2)
print(points.shape)
print(points)
m, n = np.shape(points)
print(m)
print(n)

def f_Roulette(_list):
    tr = random.random()
    for i in range(len(_list)):
        if i == 0 and _list[i] > tr:
            return 0
        else:
            if _list[i] > tr and _list[i - 1] <= tr:
                return i

def nearest(point, cluster_centers):
    min_dist = 90000000
    #当前已经初始化聚类中心的个数
    m = np.shape(cluster_centers)[0]
    #print('m = ', m)
    for i in range(m):
        #计算point与每个聚类中心之间的距离
        d = Eclud_dist(point, cluster_centers[i, ])
        #选择最短距离
        if min_dist > d:
            min_dist = d
    return min_dist

#得到初始的聚类中心
def get_cluster_origin_cent(points, k):
    #因为我们的数据是二维的，所以n是2
    m, n = np.shape(points)
    cluster_centers = np.mat(np.zeros((k, n)))
    #随机选择第一个聚类中心
    index = np.random.randint(0, m)
    #把聚类中心复制到数组里保存
    cluster_centers[0,] = np.copy(points[index,])

    #初始化一个距离序列
    d = [0.0 for _ in range(m)]
    #从第二个聚类中心开始找，一共找k个（最高的索引为k-1）
    for i in range(1, k):
        sum_denominator = 0
        sum_numerator = []
        for j in range(m):
            #对每一个样本找到最近的聚类中心点
            d[j] = nearest(points[j,], cluster_centers[0:i, ])
            #将所有的最短距离相加
            sum_denominator += d[j]
            sum_numerator.append(sum_denominator)
        sum_numerator = sum_numerator / sum_denominator
        #使用轮盘来得到随机中心点
        index = f_Roulette(sum_numerator)
        cluster_centers[i,] = np.copy(points[index,])

    return cluster_centers



cluster_centers = get_cluster_origin_cent(points, 3)
cluster_centers_display = cluster_centers.T.A
print(cluster_centers_display)
x1 = cluster_centers_display[0]
x2 = cluster_centers_display[1]
#print(x1)
plt.scatter(x1,x2,s = 40, c='red') #画点
plt.show()



def kMeans(points, k, cluster_centers):
    m, n = np.shape(points)
    # 分类及质心距离，第一列存放该数据所属的中心点，第二列是该数据到中心点的距离
    clusterAssment = mat(zeros((m, 2)))
    print(cluster_centers)
    print(points.shape)
    #判断是否收敛的标志
    clusterConvergence = False
    while not clusterConvergence:
        clusterConvergence = True;
        #对当前每个点进行分类
        for i in range(m):
            minDist = 90000000
            minIndex = -1
            for j in range(k):
                distPoint2Center = Eclud_dist(cluster_centers[j, :], points[i, :])
                if distPoint2Center < minDist:
                    minDist = distPoint2Center
                    minIndex = j
                #如果有元素分类改变了，就说明没有收敛
                if clusterAssment[i, 0] != minIndex:
                    clusterConvergence = False
                clusterAssment[i, :] = minIndex, minDist ** 2

        #先把以前的中心点保留
        cluster_centers_display = cluster_centers.T.copy()


        #划分好以后就重新计算中心点位置
        for centers in range(k):
            #取第一列等于centers的所有列 .A是将mat转化为数组
            pointsInClust = points[nonzero(clusterAssment[:, 0].A == centers)[0]]
            # 分类好以后就可视化一下
            x1 = pointsInClust.T[0]
            x2 = pointsInClust.T[1]
            if centers == 0:
                plt.scatter(x1, x2, s=5, c='red')  # 画点
            elif centers == 1:
                plt.scatter(x1, x2, s=5, c='green')  # 画点
            else:
                plt.scatter(x1, x2, s=5, c='blue')  # 画点
            #算出这些数据的中心点
            cluster_centers[centers, :] = mean(pointsInClust, axis=0)
        #把以前的中心点画出来
        clusterx1 = cluster_centers_display[0]
        clusterx2 = cluster_centers_display[1]
        plt.scatter(clusterx1, clusterx2, s=160, c='black')  # 画点

        plt.show()
    return cluster_centers, clusterAssment

#算法调用
kMeans(points, 3, cluster_centers.A)











